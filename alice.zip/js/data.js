var jasmina = {
    id: '001',
    name: 'Jasmina',
    images: [
                    '../assets/images/Jasmina3.jpg',
                    '../assets/images/Jasmina4.jpg',
                    '../assets/images/Jasmina7.jpg',

                ],
    skills: ['Usherette', 'escort'],
    indexing: ['usher', 'escort']

};

var bruna = {
    id: '002',
    name: 'Bruna',
    images: [
                    '../assets/images/Jasmina3.jpg',
                    '../assets/images/Jasmina4.jpg',
                    '../assets/images/Jasmina7.jpg',

                ],
    skills: ['Usherette', 'escort'],
    indexing: ['usher', 'escort']

};
