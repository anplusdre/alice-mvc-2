/// <reference path="js/angular.js" />

(function () {

    var alice = angular
        .module('alice', [])
        .controller('AliceController', ['$scope', '$http', function ($scope, $http) {

            //            this is where the JSON from api.php is consumed
            $http.get('api.php').
            then(function (res) {
                // here the data from the api is assigned to a variable named users
                $scope.talents = res.data.talents;


                $.noConflict();
                jQuery(document).ready(function ($) {


                    //Hamburger Menu
                    $('.stackMenu a').click(function (event) {
                        $('.rw').toggleClass('active');
                        event.preventDefault();
                    });

                    $('.fixedMenu .stackMenu a').click(function (event) {
                        $(this).children('.rw').toggleClass('active');
                        event.preventDefault();
                    });

                    $('.navigation a').click(function (e) {
                        e.preventDefault();
                        $('.navigation a').removeClass('active');
                        $(this).addClass('active');
                    });

                    var $items = $('.card');
                    var $btns = $('.nav-unsorted li a').click(function () {
                        if (this.id == 'all') {
                            $items.show().fadeIn(450);
                        } else {
                            var $el = $('.' + this.id).show().fadeIn(450);
                            $items.not($el).hide().fadeOut(450);
                        }
                        $btns.removeClass('active');
                        $(this).addClass('active');
                    })


                    //MODAL
                    $("#modalSearch").animatedModal({
                        animatedIn: 'slideInDown',
                        animatedOut: 'slideOutUp',
                        color: '#295252d6',
                        beforeOpen: function () {

                            var children = $(".thumb");
                            var index = 0;

                            function addClassNextChild() {
                                if (index == children.length) return;
                                children.eq(index++).show().velocity("transition.expandIn", {
                                    opacity: 1,
                                    stagger: 250
                                });
                                window.setTimeout(addClassNextChild, 200);
                            }

                            addClassNextChild();

                        },
                        afterClose: function () {
                            $(".thumb").hide();

                        }
                    });

                    //MODAL TALENT PROFILE

                    var moreData = $('.moreBtn');

                    moreData.click(function () {
                        $(".modalData").fadeIn({
                            queue: false,
                            duration: 'slow'
                        });
                        $('.modalData, .modalOverlay').animate({
                            opacity: '1'
                        }, 'slow');

                        $('.modalData, .modalOverlay').css({
                            zIndex: '99'
                        });

                    });

                    $('#closeData').click(function () {
                        $(".modalData").fadeOut({
                            queue: false,
                            duration: 'slow'
                        });
                        $('.modalData, .modalOverlay').animate({
                            opacity: '0'
                        }, 'slow');

                        $('.modalData, .modalOverlay').css({
                            zIndex: '-99'
                        });

                    });



                    $(window).scroll(function () {
                        if ($(window).scrollTop() >= 400) {
                            $('.fixedMenu').show();
                        } else {
                            $('.fixedMenu').hide();
                        }
                    });



                    $('.media').mouseenter(function () {
                        $(this).find('div').css({
                            display: 'block'
                        });
                        $(this).slick({
                            autoplay: true,
                            arrows: false,
                            pauseOnFocus: true,
                            dots: true,
                            dotsClass: 'timeSlide',
                            pauseOnDotsHover: false,
                            infinite: false,
                            speed: 1000,
                            slidesToShow: 1,
                            slidesToScroll: 1
                        });
                    });



                    $('.media').mouseleave(function () {

                        $(this).slick("unslick");
                        $('.hide').css({
                            display: 'none'
                        })


                    });

                    /*$('.media').mouseenter(function(){
                                    $(this).children('div').animate({
                                        opacity: '1'
                                    },200 )
                                });
                        
                                $('.media').mouseleave(function(){
                                    $(this).children('div').animate({
                                        opacity: '0'
                                    },200 )
                                });*/




                    /*function slideShow()
                    {
                        window.setInterval("changeImage()", 500);
                    }

                    function changeImage()
                    {   
                    var imgSrcs = ["images//traps//1.jpg",
                        "images//traps//2.jpg",
                        "images//traps//3.jpg",
                        "images//traps//4.jpg"]
                    var i = Math.floor((Math.random() * 3));
                    var element = document.getElementById("slideShow");
                    element.src= imgSrcs[i];
                    }*/





                });
            });
        }]);


    //.controller('AliceController', ['$scope', '$http', function ($scope, $http) {
    //        $http({
    //            method: 'get',
    //            url: 'getData.php'
    //        }).then(function successCallback(response) {
    //            $scope.talents = response.data
    //        });
    //        }]);
    //
    //
    //    var talents = [
    //        {
    //            id: '001',
    //            name: 'Jasmina',
    //            images: [
    //                                    ' assets/images/Jasmina3.jpg',
    //                                    ' assets/images/Jasmina4.jpg',
    //                                    ' assets/images/Jasmina7.jpg'
    //
    //                                ],
    //            skills: [
    //                {
    //                    name: 'Usherette'
    //                                        },
    //                {
    //                    name: 'Escort'
    //                                        }
    //                                    ],
    //            indexing: ['usher', 'Escort'],
    //            likes: 0
    //
    //                        },
    //
    //        {
    //            id: '002',
    //            name: 'Bruna',
    //            images: [
    //                                    ' assets/images/BrunaD17.jpg',
    //                                    ' assets/images/BrunaD18.jpg',
    //                                    ' assets/images/BrunaD10.jpg'
    //
    //                                ],
    //            skills: [
    //                {
    //                    name: 'Usherette'
    //                                        },
    //                {
    //                    name: 'Escort'
    //                                        }
    //                                    ],
    //            indexing: ['usher', 'Escort'],
    //            likes: 0
    //
    //                        },
    //
    //        {
    //            id: '003',
    //            name: 'Anda',
    //            images: [
    //                                    ' assets/images/Anda.jpg',
    //                                    ' assets/images/Anda8.jpg',
    //                                    ' assets/images/Anda11.jpg'
    //
    //                                ],
    //            skills: [
    //                {
    //                    name: 'Usherette'
    //                                        },
    //                {
    //                    name: 'Escort'
    //                                        },
    //                {
    //                    name: 'Modelling'
    //                                        }
    //                                    ],
    //            indexing: ['usher', 'Escort', 'model'],
    //            likes: 0
    //
    //                        },
    //
    //        {
    //            id: '004',
    //            name: 'Anne',
    //            images: [
    //                                    ' assets/images/AnneD8.jpg',
    //                                    ' assets/images/AnneD17.jpg',
    //                                    ' assets/images/AnneD21.jpg'
    //
    //                                ],
    //            skills: [
    //                {
    //                    name: 'Modelling'
    //                                        }
    //                                    ],
    //            indexing: ['model'],
    //            likes: 0
    //
    //                        }
    //                ];
    //            $scope.talents = talents;




})();
