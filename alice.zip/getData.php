<?php 

include 'config.php';

$sel = mysqli_query($con,"select * from talents");
$data = array();

while ($row = mysqli_fetch_array($sel)) {
     $data[] = array("id"=>$row['id'],"name"=>$row['name'],"images"=>$row['images'],"skills"=>$row['skills'],"indexing"=>$row['indexing']);
    }
    echo json_encode($data);

?>
